# Dictionaries with the user's words

MovementList = [['tomar','toma','tomalo', 'tomes','sujetar','sujeta','sujetalo','sujetes','coger','coge','cógelo','cojas','agarrar','agarra','agárralo','agarres'],
                ['poner','ponlo','pon','ponla','ponerlo','pongas','dejar','deja','dejes','situar','sitúa','sitúalo','mover','muévelo','muevas','suéltalo','suelte']]


RegionList = [['derecha','izquierda','centro'],
              ['borrar','eliminar','quitar']]


ObjectColor = [['azul','azulado','azulada','azules'],
                ['verde','verdoso','verdes'],
                ['amarillo','amarilla','amarillos']]

RegionList = [['arriba'],
              ['abajo'],
              ['izquierda'],
              ['derecha']]

GreetingsList =['hola', 'buenos días', 'buenas tardes', 'buenas noches', 'Hola, que tal', 'Bienvenidos a su peor pesadilla', 
                'Es bueno volver a verte', 'Hola mundo', 'Te extrañé', 'No te he olvidado', '¿Cómo dijiste que te llamabas?',
                'Que bueno que vinieron', '¡Regresaste!', '¿Qué tal?']
