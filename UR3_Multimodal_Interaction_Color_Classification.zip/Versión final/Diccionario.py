# Diccionario con las palabras de y para el usuario

ListaMovimientos = [['tomar','toma','tomalo', 'tomes','sujetar','sujeta','sujetalo','sujetes','coger','coge','cógelo','cojas','agarrar','agarra','agárralo','agarres'],
                ['poner','ponlo','pon','ponla','ponerlo','pongas','dejar','deja','dejes','situar','sitúa','sitúalo','mover','muévelo','muevas','suéltalo','suelte']]

ColorDeObjetos = [['azul','azulado','azulada','azules'],
                ['verde','verdoso','verdes'],
                ['amarillo','amarilla','amarillos']]

ListaDeSaludos =['hola', 'Hola', 'Buenos días','buenos días', 'Buenas tardes', 'buenas tardes',
                  'Hola, que tal', 'Es bueno volver a verte', '¡Regresaste!', '¿Qué tal?']

PreguntasTareas =[ '¿quieres que aprenda una tarea o que la ejecute?']

AprenderTarea =['aprende una tarea', 'aprenda una tarea', 'aprender tarea', 'aprendas una tarea']

EjecutarTarea = ['ejecuta una tarea', 'ejecute una tarea', 'ejecutar una tarea', 'ejecutes una tarea']

ClasificaCubosAzules = ['clasifica los cubos azules', 'clasifiques los cubos azules', 'clasifique los cubos azules', 'clasificar los cubos azules']

ClasificaCubosVerdes = ['clasifica los cubos verdes', 'clasifiques los cubos verdes', 'clasifique los cubos verdes', 'clasificar los cubos verdes']





